<?php

namespace App\Http\Controllers;
use App\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PostController extends Controller
{
    public function index(){
        $posts = Post::all();
        return view('index', compact ('posts'));
        //return json_encode($posts);
    }

    public function show(){
        $post = Post::all();
        return view('index2', compact ('posts'));
    }
}
