<?php
namespace App\Http\Controllers;
use App\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index(){
        $posts = Post::all();
        return view('index', compact ('posts'));
        //return json_encode($posts);
    }

    public function show(){
    	$post = Post::all()->toArray();
		//json_decode($post, true);
    	$out = array_values($post);
		json_encode($out);
		dd ($out);

        //$hidden = ['post'];
        //$converted = ($post) ? 'true' : 'false';
        //$converted = json_encode($post);
        //json_decode(string $converted[,bool $assoc=false [,int $depth=512 [,int $options=0]]]);
		//dd($converted);
    }
}